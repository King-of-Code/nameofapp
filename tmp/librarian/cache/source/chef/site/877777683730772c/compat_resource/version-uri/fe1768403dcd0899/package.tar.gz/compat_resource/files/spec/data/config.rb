local_mode true
chef_repo_path File.dirname(__FILE__)
#log_level :debug
