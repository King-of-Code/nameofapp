module CompatResource
  VERSION = '12.10.4'
end
